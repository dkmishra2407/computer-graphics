#include<GL/glut.h>
#include<GL/gl.h>
#include<iostream>
using namespace std;

int n;
int choice = 0;
int u1,v1,u2,v2;

////////////////////////////////////////////// init FUNCTION /////////////////////////////////////////////////////////////////

void init(){
   glClearColor(1.0,1.0,1.0,1.0);
   glClear(GL_COLOR_BUFFER_BIT);
   gluOrtho2D(0,680,0,420);
}

////////////////////////////////////////////// display FUNCTION /////////////////////////////////////////////////////////////////

void display(int x,int y){
   glPointSize(2);
   glColor3f(1.0,0.0,0.0);
   glBegin(GL_POINTS);
   glVertex2i(x,y);
   glEnd();
}

////////////////////////////////////////////// dotted_line FUNCTION /////////////////////////////////////////////////////////////////

void dotted_line(int x1,int y1,int x2,int y2){
   int dx = x2-x1;
   int dy = y2-y1;
   
   int steps = 0;
   
   if(abs(dx)>abs(dy)){
       steps = abs(dx);
   }
   else{
       steps = abs(dy);
   }
   
   int xinc = dx/steps;
   int yinc = dy/steps;
   
   int x = x1;
   int y = y1;
   
   for(int i=0;i<steps;i++){
       if(i%15==5 || i%15==6 || i%15==7 || i%15==8 || i%15==9 || i%15==10 ){
          display(x,y);
       }
       x += xinc;
       y += yinc;
   }
   
   glFlush();
}

////////////////////////////////////////////// dash_dot FUNCTION /////////////////////////////////////////////////////////////////

void dash_dot(int x1,int y1,int x2,int y2){
   int dx = x2-x1;
   int dy = y2-y1;
   
   int steps = 0;
   
   if(abs(dx)>abs(dy)){
       steps = abs(dx);
   }
   else{
       steps = abs(dy);
   }
   
   int xinc = dx/steps;
   int yinc = dy/steps;
   
   int x = x1;
   int y = y1;
   
   for(int i=0;i<steps;i++){
       if(i%15==5 || i%15==6 || i%15==7 || i%15==8 || i%15==9 || i%15==10){
          display(x,y);
       }
       else if(i%15==0){
          display(x,y);
       }
       x += xinc;
       y += yinc;
   }
   
   glFlush();
}

////////////////////////////////////////////// simple_line FUNCTION /////////////////////////////////////////////////////////////////

void simple_line(int x1,int y1,int x2,int y2){
   int dx = x2-x1;
   int dy = y2-y1;
   
   int steps = 0;
   
   if(abs(dx)>abs(dy)){
       steps = abs(dx);
   }
   else{
       steps = abs(dy);
   }
   
   int xinc = dx/steps;
   int yinc = dy/steps;
   
   int x = x1;
   int y = y1;
   
   for(int i=0;i<steps;i++){
      display(x,y);
       x += xinc;
       y += yinc;
   }
   
   glFlush();
}

////////////////////////////////////////////// draw FUNCTION /////////////////////////////////////////////////////////////////
void draw(){

   switch(choice){
      case 1:
         dotted_line(u1,v1,u1+n,v1); 
         break;
         
      case 2:
         dash_dot(u1,v1,u1+n,v1);
         break;
         
      case 3:
         simple_line(u1,v1,u1+n,v1);
         break;
   }
   
}

////////////////////////////////////////////// MOUSE FUNCTION /////////////////////////////////////////////////////////////////
void mouseclick(int button , int state , int x , int y){

     if(button==GLUT_LEFT && state == GLUT_DOWN ){
         u1 = x;

         v1 = 420-y;
         draw();
     }
     glFlush();
}

////////////////////////////////////////////// MENU FUNCTION /////////////////////////////////////////////////////////////////

void menu(int option){
     switch(option){
      case 1:
          cout<<"ENTER THE LENGTH OF THE LINE 0<X<400: \n";
          cin>>n;
          cout<<"ENTER FIRST AND LAST POINT : ";
          cin>>u1>>v1;
          dotted_line(u1,v1,u1+n,v1); 
         break;
         
      case 2:
          cout<<"ENTER THE LENGTH OF THE LINE 0<X<400: \n";
          cin>>n;
          cout<<"ENTER FIRST AND LAST POINT : ";
          cin>>u1>>v1;
         dash_dot(u1,v1,u1+n,v1);
         break;
         
      case 3:
          cout<<"ENTER THE LENGTH OF THE LINE 0<X<400: \n";
          cin>>n;
          cout<<"ENTER FIRST AND LAST POINT : ";
          cin>>u1>>v1;
          simple_line(u1,v1,u1+n,v1);
          break;
        
   }
}

////////////////////////////////////////////// MAIN FUNCTION /////////////////////////////////////////////////////////////////
int main(int argc , char** argv){
    cout<<"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ DDA LINES $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$";
    cout<<"\n\n1. DOTTED LINE\n2. DASH DOT DASH LINE \n3.SIMPLE LINE \nENTER YOUR CHOICE: \n\n";
    cin>>choice;
    cout<<"ENTER THE LENGTH OF THE LINE 0<X<400: \n";
    cin>>n;
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(680,420);
    glutInitWindowPosition(0,0);
    glutCreateWindow("DDA LINES");
    init();
    glutMouseFunc(mouseclick);
    glutCreateMenu(menu);
    glutAddMenuEntry("1. DOTTED LINE",1);
    glutAddMenuEntry("2. DASH DOT DASH LINE",2);
    glutAddMenuEntry("3. SIMPLE LINE",3);
    glutAttachMenu(GLUT_RIGHT_BUTTON);
    glutMainLoop();
    return 0;
}
