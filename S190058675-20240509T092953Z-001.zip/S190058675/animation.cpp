#include<GL/glut.h>
#include<GL/gl.h>

GLfloat angle = 0.0;

////////////////////////////////////////////// init FUNCTION /////////////////////////////////////////////////////////////////
void init(){
    glEnable(GL_DEPTH_TEST);
    glClearColor(0.0,0.0,0.0,1.0);
}

////////////////////////////////////////////// display FUNCTION /////////////////////////////////////////////////////////////////

void display(){
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   glLoadIdentity();
   glTranslatef(1.0,0.0,0.0);
   glRotatef(angle,1.0,0.0,0.0);
   
   glBegin(GL_QUADS);
   
   glColor3f(1.0,0.0,0.0);
   glVertex3f(-1.0,-1.0,1.0);
   glVertex3f(-1.0,1.0,1.0);
   glVertex3f(1.0,1.0,1.0);
   glVertex3f(1.0,-1.0,1.0);
   
   glColor3f(0.0,1.0,0.0);
   glVertex3f(1.0,-1.0,-1.0);
   glVertex3f(1.0,-1.0,1.0);
   glVertex3f(1.0,1.0,1.0);
   glVertex3f(1.0,1.0,-1.0);
   
   glColor3f(0.0,0.0,1.0);
   glVertex3f(-1.0,1.0,-1.0);
   glVertex3f(1.0,1.0,-1.0);
   glVertex3f(1.0,1.0,1.0);
   glVertex3f(-1.0,1.0,1.0);
   
   glColor3f(1.0,0.0,1.0);
   glVertex3f(-1.0,-1.0,-1.0);
   glVertex3f(-1.0,-1.0,1.0);
   glVertex3f(-1.0,1.0,1.0);
   glVertex3f(-1.0,1.0,-1.0);
   
   glColor3f(0.0,1.0,1.0);
   glVertex3f(-1.0,-1.0,-1.0);
   glVertex3f(1.0,-1.0,-1.0);
   glVertex3f(1.0,-1.0,1.0);
   glVertex3f(-1.0,-1.0,1.0);
   
   glColor3f(1.0,1.0,0.0);
   glVertex3f(-1.0,-1.0,-1.0);
   glVertex3f(-1.0,1.0,-1.0);
   glVertex3f(1.0,1.0,-1.0);
   glVertex3f(1.0,-1.0,-1.0);
   glEnd();
   
   glutSwapBuffers();
   
   glFlush();
}


////////////////////////////////////////////// reshape FUNCTION /////////////////////////////////////////////////////////////////

void reshape(int w,int h){
   glViewport(0,0,(GLsizei)w,(GLsizei)h);
   glLoadIdentity();
   glMatrixMode(GL_PROJECTION);
   gluPerspective(60,(GLfloat)w/(GLfloat)h,1.0,100.0);
   glMatrixMode(GL_MODELVIEW);
}

////////////////////////////////////////////// idle FUNCTION /////////////////////////////////////////////////////////////////

void idle(){
   angle += 0.5;
   if(angle>360.0){
      angle -= 360.0;
   }
   glutPostRedisplay();
}


////////////////////////////////////////////// MAIN FUNCTION /////////////////////////////////////////////////////////////////

int main(int argc , char** argv){

    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(600,600);
    glutInitWindowPosition(0,0);
    glutCreateWindow("ANIMATION");
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutIdleFunc(idle);
    glutMainLoop();
    return 0;
}
